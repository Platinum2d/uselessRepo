from setuptools import setup, find_packages

setup(
    name='django-champions-league-manager',
    version='1.0',
    packages=find_packages(),
    author='daniele',
    scripts=["manage.py"],
    author_email='manicardi215@gmail.com',
    description='A simple manager for a UEFA Champions League edition'
)
